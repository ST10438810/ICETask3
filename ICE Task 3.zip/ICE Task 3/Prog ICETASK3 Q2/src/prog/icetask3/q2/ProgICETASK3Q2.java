/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prog.icetask3.q2;

/**
 *
 * @author gg
 */
import java.util.stream.*;

public class ProgICETASK3Q2 {

    public static void main(String[] args) {
        // Test the generator function
        int limit = 10;
        System.out.println("Sum of squares of odd numbers up to " + limit + ": " + oddSquaresSum(limit));
    }

    public static int oddSquaresSum(int limit) {
        return IntStream.iterate(1, n -> n + 2)   // Generate odd numbers
                        .limit(limit)
                        .map(n -> n * n)         // Square each odd number
                        .sum();                   // Sum up the squared odd numbers
    }
}

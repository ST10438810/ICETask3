/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prog.icetask3.q3;

/**
 *
 * @author gg
 */
import java.util.Scanner;
public class ProgICETASK3Q3 {
 
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the first number: ");
        int a = scanner.nextInt();
        System.out.print("Enter the second number: ");
        int b = scanner.nextInt();
        
        int gcd = greatestCommonDivisor(a, b);
        
        System.out.println("The greatest common divisor of " + a + " and " + b + " is: " + gcd);
        
        scanner.close();
    }
    
    public static int greatestCommonDivisor(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }
}
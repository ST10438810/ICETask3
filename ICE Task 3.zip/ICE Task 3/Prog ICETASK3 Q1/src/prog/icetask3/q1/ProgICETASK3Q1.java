/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prog.icetask3.q1;

/**
 *
 * @author gg
 */
public class ProgICETASK3Q1 {

    public static String StringValid(String s) {
        if (s == null || s.length() == 0) return "invalid";
        if (s.length() % 2 != 0) return "invalid"; // If the length is odd, it can't be valid
        
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (c == '(' || c == '{' || c == '[') {
                sb.append(c); // If it's an opening bracket, append it to the StringBuilder
            } else {
                if (sb.length() == 0) return "invalid"; // If it's a closing bracket and StringBuilder is empty, return false
                
                char lastOpen = sb.charAt(sb.length() - 1);
                if ((c == ')' && lastOpen == '(') ||
                    (c == '}' && lastOpen == '{') ||
                    (c == ']' && lastOpen == '[')) {
                    sb.deleteCharAt(sb.length() - 1); // If it's a closing bracket and matches with the last open bracket, remove it from the StringBuilder
                } else {
                    return "invalid"; // If it's a closing bracket but doesn't match with the last open bracket, return false
                }
            }
        }
        return sb.length() == 0 ? "valid" : "invalid"; // If StringBuilder is empty, it's valid
    }

    public static void main(String[] args) {
        // Test cases
        System.out.println(StringValid("{}{)}")); // invalid
        System.out.println(StringValid(""));      // invalid
        System.out.println(StringValid("{[}]"));  // invalid
        System.out.println(StringValid("()"));    // valid
        System.out.println(StringValid("({[]})")); // valid
    }
}
